package com.example.clientapi.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.clientapi.model.Client;
import com.example.clientapi.service.ClientService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/v1")
@Tag(name = "Apresentação Spring Boot", description = "API que demostra o cadastro, consulta e exclusão de cliente!!")
public class ClientController {

    private static final Logger logger = LoggerFactory.getLogger(ClientController.class);
    private final ClientService service ;
    public ClientController(ClientService service){
        this.service = service;
    }
    

    @GetMapping(path = "/clientesAll")
    @Operation(summary = "Lista todos clientes", description = "Retornará todos os clientes cadastrados na base.")
    public List<Client> getAllClients() {
        List<Client> client = service.ListClient();
        logger.info("Resultado da busca de clientes: {}", client.toString());
        return client;
    }

    @PostMapping(path = "/clientes")
    @Operation(summary = "Cadastra cliente", description = "Cadastra cliente na base.")
    public Client createClient(@RequestBody @Valid Client client) {
        logger.info("Criando cliente: {}", client.getNome());
        return service.createClient(client);
    }

    @DeleteMapping("/clientes/{id}")
    @Operation(summary = "Exclui cliente", description = "Exclui cliente na base...")
    public ResponseEntity<String> deleteCliente(@PathVariable Long id) {
        return service.deleteCliente(id);
    }
}