package com.example.clientapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.example.clientapi.model.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {
  List<Client> findByNomeContainingIgnoreCase(String nome);

  // Buscar cliente por nome
  //  Optional<Client> findByNome(String nome);

  // Atualizar nome e email de um cliente existente teste
  @Modifying
  @Transactional
  @Query("UPDATE Client c SET c.nome = :nome, c.email = :email WHERE c.id = :id")
  void atualizarCliente(Long id, String nome, String email);
}