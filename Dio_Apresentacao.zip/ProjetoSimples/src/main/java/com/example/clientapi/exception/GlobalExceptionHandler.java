
package com.example.clientapi.exception;

import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@ControllerAdvice
@RestControllerAdvice(basePackages = "com.example.clientapi.controller")
public class GlobalExceptionHandler {

     private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
   
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("timestamp", OffsetDateTime.now());
        response.put("status", ex.getStatusCode().value());
        response.put("erro", ex.getStatusCode().toString());
        response.put("path", "/clientes");

        String causa = ex.getBindingResult().getFieldErrors().stream()
            .map(error -> "message [" + error.getDefaultMessage() + "]")
            .findFirst()
            .orElse("Erro de validação");

        response.put("Causa", causa);
        logger.error("Resultado da Erro: {}",response.toString());
        logger.error("Stacktrace: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(response);
    }
}
