package com.example.clientapi.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.clientapi.model.Client;
import com.example.clientapi.service.ClientService;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/v1")
public class ClientController {

    private static final Logger logger = LoggerFactory.getLogger(ClientController.class);
    private final ClientService service ;
    public ClientController(ClientService service){
        this.service = service;
    }
    
    @GetMapping(path = "/clientesAll")
    public List<Client> getAllClients() {
        List<Client> client = service.ListClient();
        logger.info("Resultado da busca de clientes: {}", client.toString());
        return client;
    }

    @PostMapping(path = "/clientes")
    public Client createClient(@RequestBody @Valid Client client) {
        logger.info("Criando cliente: {}", client.getNome());
        return service.createClient(client);
    }

    @GetMapping(path = "/clientes{nome}")
    public ResponseEntity<List<Client>> getClientesByNome(@RequestParam(required = false) String nome) {
        List<Client> client = service.listClientByNome(nome);
        logger.info("Resultado da busca de clientes: {}", client.toString());
        return ResponseEntity.ok(client);
       
    }

    @DeleteMapping("/clientes/{id}")
    public ResponseEntity<String> deleteCliente(@PathVariable Long id) {
        return service.deleteCliente(id);
    }

    @PutMapping("/clientes/{id}")
    public ResponseEntity<String> atualizarCliente(@PathVariable Long id, @RequestBody Client client) {
        return service.atualizarCliente(id, client);
    }
}