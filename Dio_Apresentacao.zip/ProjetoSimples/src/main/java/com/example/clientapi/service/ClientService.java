package com.example.clientapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.clientapi.model.Client;
import com.example.clientapi.repository.ClientRepository;

@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    public List<Client> ListClient() {
       return clientRepository.findAll();
    }

    public Client createClient(Client client) {
        return clientRepository.save(client);
    }

     public List<Client> listClientByNome(String nome) {
        List<Client> client = clientRepository.findByNomeContainingIgnoreCase(nome);
        return client;
       
    }

    public ResponseEntity<String> deleteCliente(Long id) {
        Optional<Client> clientExist = clientRepository.findById(id);
        if (clientExist.isPresent()) {
            clientRepository.deleteById(id);
            return ResponseEntity.ok("Cliente excluido com sucesso.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }        
    }

    public ResponseEntity<String> atualizarCliente(Long id, Client client) {
        Optional<Client> clientExist = clientRepository.findById(id);
        if (clientExist.isPresent()) {
            clientRepository.atualizarCliente(id, client.getNome(), client.getEmail());
            return ResponseEntity.ok("Cliente atualizado com sucesso.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }
    }
}
